package com.example.begoe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnReg,btnSig,btn1;
    private  final  String CHANNEL_ID ="Dog barking";
    private  final  int NOTIFICATION_ID =001;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnReg = (Button) findViewById(R.id.registerBtn);
        btnSig = (Button) findViewById(R.id.submit);
        //btn1 = (Button) findViewById(R.id.btn);

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
        btnSig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            }
        });

    }


       /* btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                addNotification();
            }
        });

    }*/
        /*public void addNotification() {
            //String message = "Notification Dog bark.";
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this,CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_warning)
                    .setContentTitle("BeeGoe Notification")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setContentText("Your dog barking somethings!");


            NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
            notificationManagerCompat.notify(NOTIFICATION_ID,builder.build());
                  //  .setAutoCancel(true);


            //Intent intent = new Intent(this,MainActivity.class);
           // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
           // intent.putExtra("message", message);

           // PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
           // builder.setContentIntent(pendingIntent);

           // NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
           // notificationManager.notify(0, builder.build());


        }

*/

    public void displayNotification(View view) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID);
        builder.setSmallIcon(R.drawable.ic_warning);
        builder.setContentTitle("BeeGoe Notification");
        builder.setContentText("Your dog barking somethings!");
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManagerCompat = NotificationManagerCompat.from(this);
        notificationManagerCompat.notify(NOTIFICATION_ID, builder.build());
    }


}
