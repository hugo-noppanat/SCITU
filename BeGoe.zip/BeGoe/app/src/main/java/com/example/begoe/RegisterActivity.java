package com.example.begoe;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RegisterActivity extends AppCompatActivity {
      //  EditText mFirstName,mLastName,mEmail,mPassword,mConfirmPasswprd,mPhone;
      //  Button mRegister;
      //  TextView mLogin;
      //  FirebaseAuth fAuth;
      //  ProgressBar progressBar;
//    private Button btn;
//
    AutoCompleteTextView name,lastName,email,userName,password,phoneNumber;
    Button btnReg;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_register);
        name = (AutoCompleteTextView)findViewById(R.id.firstName);
        lastName = (AutoCompleteTextView)findViewById(R.id.lastName);
        email = (AutoCompleteTextView)findViewById(R.id.email);
        userName = (AutoCompleteTextView)findViewById(R.id.userName);
        password = (AutoCompleteTextView)findViewById(R.id.password);
        phoneNumber = (AutoCompleteTextView)findViewById(R.id.phone);

        btnReg = (Button) findViewById(R.id.registerBtn);

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HttpGetRequest post = new HttpGetRequest(name.getText().toString(),lastName.getText().toString(),email.getText().toString(),userName.getText().toString(),password.getText().toString()
                        ,phoneNumber.getText().toString());
                post.execute();
            }
        });


    /*
        mFirstName = findViewById(R.id.firstName);
        mLastName = findViewById(R.id.lastName);
        mEmail = findViewById(R.id.email);
        mPassword = findViewById(R.id.password);
        mConfirmPasswprd = findViewById(R.id.confirmPassword);
        mPhone = findViewById(R.id.phone);
        mRegister = findViewById(R.id.registerBtn);
        mLogin = findViewById(R.id.loginText);

        fAuth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progressBar);

        if(fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
        }

        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmail.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    mEmail.setError("Email is Reguurd.");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    mPassword.setError("Password is Required.");
                    return;
                }
                if(password.length()<6){
                    mPassword.setError("Password must be more than 6 charaters.");
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(RegisterActivity.this,"User Created.",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        }
                        else {
                            Toast.makeText(RegisterActivity.this,"Error !"+task.getException().getMessage(),Toast.LENGTH_SHORT).show();

                        }
                    }
                });
            }
        });

    */
//     btn = (Button) findViewById(R.id.RegisterActivity);
//
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(this, RegisterActivity.class);
//                startActivity(intent);
//            }
//        });
    }

    private class HttpGetRequest extends AsyncTask<Void, Void, Void> {
        String name ,lastName , email,username,password,Phone;
        String url1 = ("http://192.168.43.246:1234/register");
        HttpGetRequest(String name,String lastName,String email,String username,String password,String Phone ){

            this.name = name;
            this.lastName = lastName;
            this.email = email;
            this.username = username;
            this.password = password;
            this.Phone = Phone;
        }

        @Override
        protected Void doInBackground(Void... strings){
            OkHttpClient client = new OkHttpClient();

            RequestBody formBody = new FormBody.Builder()
                    .add("name", username)
                    .add("username",name)
                    .add("password",password)
                    .add("email",email)
                   // .add("ipdog","100.232.32.215")
                    .add("surname",lastName)
                    .add("phone",Phone)
                    .build();

            Request request = new Request.Builder()
                    .url(url1)
                    .post(formBody)
                    .build();

            try {
                Response response = client.newCall(request).execute();

                // Do something with the response.
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }


    }
}