package com.example.begoe;

public class Menu {
}
